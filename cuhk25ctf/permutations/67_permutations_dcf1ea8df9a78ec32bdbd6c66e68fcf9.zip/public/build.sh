#!/bin/sh
g++ -o chall chall.c
